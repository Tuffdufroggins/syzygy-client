package m_a_n.szg.module.impl.render;

import m_a_n.szg.module.Category;
import m_a_n.szg.module.Module;
import m_a_n.szg.ui.ClickGuiScreen;
import m_a_n.szg.util.RenderUtils;
import net.minecraft.entity.Entity;
import net.minecraftforge.client.event.RenderLivingEvent;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.input.Keyboard;

public class Esp extends Module {

    public Esp() {
        super("ESP", "Extrasensory Perception", Category.RENDER);
    }

    public void onEnable() {

    }

    public void onDisable() {

    }


    public void onRenderWorld() {
        for(Entity entity : mc.world.loadedEntityList) {
            if(entity != mc.player) {

                // Outline
                //RenderUtils.renderOutlineBB(entity, 86f / 255, 45f / 255, 252f / 255, 0.3);

                // Filled
                RenderUtils.renderFilledBB(entity, 86f / 255, 45f / 255, 252f / 255, 0.3);
                RenderUtils.renderOutlineBB(entity, 190f / 255, 45f / 255, 252f / 255, 0.15);


            }
        }
    }
}
