package m_a_n.szg.module.impl.movement;

import m_a_n.szg.module.Category;
import m_a_n.szg.module.Module;
import org.lwjgl.input.Keyboard;

public class Anchor extends Module {

    public Anchor() {
        super("Anchor", "Makes you fall faster", Category.MOVEMENT);
        this.setKey(Keyboard.KEY_N);
    }

    public void onEnable() {

    }

    public void onDisable() {
    }

    public void onUpdate() {
        if(mc.player != null) {
            if (mc.player.motionY < 0 && mc.player.motionY > -0.3) {
                mc.player.motionY *= 1.2;
            }
        }
    }
}
