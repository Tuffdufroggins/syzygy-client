package m_a_n.szg.module;

public enum Category {
    COMBAT("Combat", 5, 5),
    EXPLOITS("Exploits", 87, 5),
    MISC("Misc", 169, 5),
    MOVEMENT("Movement", 251, 5),
    RENDER("Render", 333, 5),
    WORLD("World", 415, 5),
    OTHER("Other", 497, 5);

    public String name;
    public int moduleIndex;

    public boolean expanded = false;
    public boolean moving = false;

    public double x, y;

    public double xoff, yoff;

    Category(String name, double x, double y) {
        this.name = name;
        this.x = x;
        this.y = y;
    }
}
