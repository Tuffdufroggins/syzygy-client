package m_a_n.szg.module.impl.combat;

import m_a_n.szg.module.Category;
import m_a_n.szg.module.Module;
import net.minecraft.block.BlockObsidian;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemEndCrystal;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.network.play.client.CPacketHeldItemChange;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.network.play.client.CPacketUseEntity;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.input.Keyboard;

public class CrystalAura extends Module {

    public CrystalAura() {
        super("CrystalAura", "Automatically places and detonates crystals near enemies", Category.COMBAT);
        this.setKey(Keyboard.KEY_P);
    }

    public void onEnable() {
        lastCrystal = null;
    }

    public void onDisable() {

    }

    BlockPos lastCrystal = null;

    public void onUpdate() {
        if(mc.world != null && mc.player != null) {
            if(lastCrystal != null && getCrystal(lastCrystal) != null && mc.player.getDistance(getCrystal(lastCrystal)) < 4) {
                Entity crystal = getCrystal(lastCrystal);
                if (crystal != null) {
                    System.out.println("HIT");
                    mc.player.connection.sendPacket(new CPacketUseEntity(crystal));
                    mc.player.swingArm(EnumHand.MAIN_HAND);
                    //mc.playerController.attackEntity(mc.player, crystal);
                }
            } else {
                Entity target = null;
                for (Entity entity : mc.world.loadedEntityList) {
                    if (entity instanceof EntityLivingBase && entity != mc.player && entity.isEntityAlive()) {
                        if (mc.player.getDistance(entity) < 4) {
                            if (target == null || mc.player.getDistance(entity) < mc.player.getDistance(target)) {
                                target = entity;
                            }
                        }
                    }
                }

                if (target != null) {
                    if (getCrystalSlot() >= 0) {

                        boolean dohax = mc.player.inventory.currentItem != getCrystalSlot();
                        if (dohax) mc.player.connection.sendPacket(new CPacketHeldItemChange(getCrystalSlot()));

                        if (mc.world.isAirBlock(target.getPosition().add(0, 0, 1)) && mc.world.isAirBlock(target.getPosition().add(0, 1, 1)) && mc.world.getBlockState(target.getPosition().add(0, -1, 1)).getBlock() instanceof BlockObsidian) {
                            if (mc.playerController.processRightClickBlock(mc.player, mc.world, target.getPosition().add(0, -1, 1), EnumFacing.DOWN, new Vec3d(0, 0, 0), EnumHand.MAIN_HAND) == EnumActionResult.SUCCESS) {
                                mc.player.swingArm(EnumHand.MAIN_HAND);
                                lastCrystal = target.getPosition().add(0, 0, 1);
                            }
                        } else if (mc.world.isAirBlock(target.getPosition().add(0, 0, -1)) && mc.world.isAirBlock(target.getPosition().add(0, 1, -1)) && mc.world.getBlockState(target.getPosition().add(0, -1, -1)).getBlock() instanceof BlockObsidian) {
                            if (mc.playerController.processRightClickBlock(mc.player, mc.world, target.getPosition().add(0, -1, -1), EnumFacing.DOWN, new Vec3d(0, 0, 0), EnumHand.MAIN_HAND) == EnumActionResult.SUCCESS) {
                                mc.player.swingArm(EnumHand.MAIN_HAND);
                                lastCrystal = target.getPosition().add(0, 0, -1);
                            }
                        } else if (mc.world.isAirBlock(target.getPosition().add(1, 0, 0)) && mc.world.isAirBlock(target.getPosition().add(1, 1, 0)) && mc.world.getBlockState(target.getPosition().add(1, -1, 0)).getBlock() instanceof BlockObsidian) {
                            if (mc.playerController.processRightClickBlock(mc.player, mc.world, target.getPosition().add(1, -1, 0), EnumFacing.DOWN, new Vec3d(0, 0, 0), EnumHand.MAIN_HAND) == EnumActionResult.SUCCESS) {
                                mc.player.swingArm(EnumHand.MAIN_HAND);
                                lastCrystal = target.getPosition().add(1, 0, 0);
                            }
                        } else if (mc.world.isAirBlock(target.getPosition().add(-1, 0, 0)) && mc.world.isAirBlock(target.getPosition().add(-1, 1, 0)) && mc.world.getBlockState(target.getPosition().add(-1, -1, 0)).getBlock() instanceof BlockObsidian) {
                            if (mc.playerController.processRightClickBlock(mc.player, mc.world, target.getPosition().add(-1, -1, 0), EnumFacing.DOWN, new Vec3d(0, 0, 0), EnumHand.MAIN_HAND) == EnumActionResult.SUCCESS) {
                                mc.player.swingArm(EnumHand.MAIN_HAND);
                                lastCrystal = target.getPosition().add(-1, 0, 0);
                            }
                        }

                        if (dohax)
                            mc.player.connection.sendPacket(new CPacketHeldItemChange(mc.player.inventory.currentItem));
                    }
                }
            }
        }
    }

    public Entity getCrystal(BlockPos pos) {
        for (Entity entity : mc.world.loadedEntityList) {
            if(entity instanceof EntityEnderCrystal)
                System.out.println(entity.getPosition() + " " + pos);
            if (entity instanceof EntityEnderCrystal && entity.getPosition().equals(pos)) {
                return entity;
            }
        }
        return null;
    }

    private int getCrystalSlot() {
        for (int i = 36; i < 45; ++i) {
            ItemStack itemStack = mc.player.inventoryContainer.getSlot(i).getStack();
            if (itemStack != null && itemStack.getItem() instanceof ItemEndCrystal) {
                return i - 36;
            }
        }
        return -1;
    }

    public float[] getNeededRotations(Entity entity) {
        final Vec3d eyesPos = new Vec3d(mc.player.posX, mc.player.posY + mc.player.getEyeHeight(), mc.player.posZ);
        final AxisAlignedBB bb = entity.getEntityBoundingBox();
        final Vec3d vec = new Vec3d(bb.minX + (bb.maxX - bb.minX) * 0.5, bb.minY + (bb.maxY - bb.minY) * 0.5, bb.minZ + (bb.maxZ - bb.minZ) * 0.5);
        final double diffX = vec.x - eyesPos.x;
        final double diffY = vec.y - eyesPos.y;
        final double diffZ = vec.z - eyesPos.z;
        final double diffXZ = Math.sqrt(diffX*diffX + diffZ*diffZ);
        final float yaw = (float)Math.toDegrees(Math.atan2(diffZ, diffX)) - 90.0f;
        final float pitch = (float) (-Math.toDegrees(Math.atan2(diffY, diffXZ)));
        return new float[] {MathHelper.wrapDegrees(yaw), MathHelper.wrapDegrees(pitch)};
    }
}
