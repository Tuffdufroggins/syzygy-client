package m_a_n.szg.module;

import net.minecraft.client.Minecraft;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

public class Module {

    private String name, description;
    public Minecraft mc;
    private Category category;
    private int key;
    private boolean toggled = false;
    public boolean shownOnHud = true;

    public Module(String name, String description, Category category) {
        super();
        this.name = name;
        this.description = description;
        this.key = 0;
        this.category = category;
        mc = Minecraft.getMinecraft();
    }

    public void onUpdate() {

    }

    public void onRenderWorld() {

    }


    public void toggle() {
        this.toggled = !toggled;

        if(toggled) {
            onEnable();
        } else {
            onDisable();
        }
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Category getCategory() {
        return category;
    }

    public void setCategory(Category category) {
        this.category = category;
    }

    public int getKey() {
        return key;
    }

    public void setKey(int key) {
        this.key = key;
    }

    public boolean isToggled() {
        return toggled;
    }

    public void setToggled(boolean toggled) {
        this.toggled = toggled;
    }

    public void onEnable() {
        MinecraftForge.EVENT_BUS.register(this);
    }
    public void onDisable() {
        MinecraftForge.EVENT_BUS.unregister(this);
    }
}
