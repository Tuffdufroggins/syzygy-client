package m_a_n.szg.module;

import m_a_n.szg.Client;
import m_a_n.szg.module.impl.combat.CrystalAura;
import m_a_n.szg.module.impl.combat.KillAura;
import m_a_n.szg.module.impl.misc.NoFall;
import m_a_n.szg.module.impl.movement.Anchor;
import m_a_n.szg.module.impl.movement.Fly;
import m_a_n.szg.module.impl.render.ClickGui;
import m_a_n.szg.module.impl.render.Esp;

import java.util.ArrayList;
import java.util.List;

public class ModuleManager {

    public ArrayList<Module> modules;

    public ModuleManager() {
        (modules = new ArrayList<Module>()).clear();

        // Combat
        modules.add(new KillAura());
        modules.add(new CrystalAura());

        // Exploits

        // Misc
        modules.add(new NoFall());

        // Movement
        modules.add(new Fly());
        modules.add(new Anchor());

        // Render
        modules.add(new ClickGui());
        modules.add(new Esp());

        // World

        // Other
    }

    public List<Module> getModulesByCategory(Category c) {
        List<Module> modules = new ArrayList<Module>();

        for(Module m : Client.moduleManager.modules) {
            if(m.getCategory() == c)
                modules.add(m);
        }

        return modules;
    }

    public Module getModule(String name) {
        for (Module m : Client.moduleManager.modules) {
            if (m.getName().equalsIgnoreCase(name)) {
                return m;
            }
        }
        return null;
    }
}
