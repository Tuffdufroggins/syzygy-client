package m_a_n.szg.module.impl.combat;

import m_a_n.szg.module.Category;
import m_a_n.szg.module.Module;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.network.play.client.CPacketUseEntity;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.PlayerEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;

public class KillAura extends Module {

    public KillAura() {
        super("KillAura", "Automatically attacks entities in range", Category.COMBAT);
        this.setKey(Keyboard.KEY_R);
    }

    public void onEnable() {
        delay = 0;
    }

    public void onDisable() {

    }

    float delay = 0;

    public void onUpdate() {
        Entity target = null;
        for(Entity entity : mc.world.loadedEntityList) {
            if(entity instanceof EntityLivingBase && entity != mc.player && entity.isEntityAlive()) {
                if(mc.player.getDistance(entity) < 4) {
                    if (target == null || mc.player.getDistance(entity) < mc.player.getDistance(target)) {
                        target = entity;
                    }
                }
            }
        }

        if(target != null) {
            //mc.player.rotationYaw = getNeededRotations((EntityLivingBase) target)[0];
            //mc.player.rotationPitch = getNeededRotations((EntityLivingBase) target)[1];
            if(delay < 0) {
                mc.player.connection.sendPacket(new CPacketPlayer.PositionRotation(mc.player.posX, mc.player.posY, mc.player.posZ, getNeededRotations((EntityLivingBase) target)[0], getNeededRotations((EntityLivingBase) target)[1], mc.player.onGround));
                mc.playerController.attackEntity(mc.player, target);
                mc.player.swingArm(EnumHand.MAIN_HAND);
                delay = mc.player.getCooldownPeriod();
            } else {
                delay -= 0.5f;
            }
        } else {
            delay = 0;
        }
    }

    public float[] getNeededRotations(final EntityLivingBase entity) {
        final Vec3d eyesPos = new Vec3d(mc.player.posX, mc.player.posY + mc.player.getEyeHeight(), mc.player.posZ);
        final AxisAlignedBB bb = entity.getEntityBoundingBox();
        final Vec3d vec = new Vec3d(bb.minX + (bb.maxX - bb.minX) * 0.5, bb.minY + (bb.maxY - bb.minY) * 0.5, bb.minZ + (bb.maxZ - bb.minZ) * 0.5);
        final double diffX = vec.x - eyesPos.x;
        final double diffY = vec.y - eyesPos.y;
        final double diffZ = vec.z - eyesPos.z;
        final double diffXZ = Math.sqrt(diffX*diffX + diffZ*diffZ);
        final float yaw = (float)Math.toDegrees(Math.atan2(diffZ, diffX)) - 90.0f;
        final float pitch = (float) (-Math.toDegrees(Math.atan2(diffY, diffXZ)));
        return new float[] {MathHelper.wrapDegrees(yaw), MathHelper.wrapDegrees(pitch) };
    }
}
