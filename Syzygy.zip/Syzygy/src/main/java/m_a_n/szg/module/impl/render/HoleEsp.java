package m_a_n.szg.module.impl.render;

import m_a_n.szg.module.Category;
import m_a_n.szg.module.Module;
import m_a_n.szg.util.RenderUtils;
import net.minecraft.block.BlockBreakable;
import net.minecraft.block.BlockObsidian;
import net.minecraft.entity.Entity;
import net.minecraft.init.Blocks;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.math.BlockPos;

public class HoleEsp extends Module {

    public HoleEsp() {
        super("HoleEsp", "Shows you the holes", Category.RENDER);
    }

    public void onEnable() {

    }

    public void onDisable() {

    }


    public void onRenderWorld() {
        for(int i = -100; i <= 100; i++) {
            for (int j = -100; j <= 100; j++) {
                for (int k = -100; k <= 100; k++) {
                    if (mc.world.isAirBlock(new BlockPos(i, j, k))) {
                        if(mc.world.getBlockState(new BlockPos(i, j-1, k)).getBlock() == Blocks.BEDROCK && mc.world.getBlockState(new BlockPos(i-1, j, k)).getBlock() == Blocks.BEDROCK && mc.world.getBlockState(new BlockPos(i+1, j, k)).getBlock() == Blocks.BEDROCK && mc.world.getBlockState(new BlockPos(i, j, k)).getBlock() == Blocks.BEDROCK)

                        // Outline
                        //RenderUtils.renderOutlineBB(entity, 86f / 255, 45f / 255, 252f / 255, 0.3);

                        // Filled
                        RenderUtils.renderFilledBB(entity, 86f / 255, 45f / 255, 252f / 255, 0.3);
                        RenderUtils.renderOutlineBB(entity, 190f / 255, 45f / 255, 252f / 255, 0.15);


                    }
                }
            }
        }
    }
}
