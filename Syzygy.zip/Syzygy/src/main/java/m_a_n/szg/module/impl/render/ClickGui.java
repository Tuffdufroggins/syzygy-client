package m_a_n.szg.module.impl.render;

import m_a_n.szg.module.Category;
import m_a_n.szg.module.Module;
import m_a_n.szg.ui.ClickGuiScreen;
import org.lwjgl.input.Keyboard;

public class ClickGui extends Module {

    public ClickGui() {
        super("ClickGui", "Opens the clickgui you are using right now", Category.RENDER);
        this.setKey(Keyboard.KEY_RSHIFT);
    }

    public void onEnable() {
        mc.displayGuiScreen(new ClickGuiScreen());
        toggle();
    }

    public void onDisable() {

    }

    public void onUpdate() {

    }
}
