package m_a_n.szg.module.impl.movement;

import m_a_n.szg.module.Category;
import m_a_n.szg.module.Module;
import org.lwjgl.input.Keyboard;

public class Fly extends Module {

    public Fly() {
        super("Fly", "Allows you to fly like a bird", Category.MOVEMENT);
        this.setKey(Keyboard.KEY_G);
    }

    public void onEnable() {
        mc.player.capabilities.isFlying = true;
    }

    public void onDisable() {
        mc.player.capabilities.isFlying = false;
    }

    public void onUpdate() {
        if(mc.player != null)
            mc.player.capabilities.isFlying = true;
    }
}
