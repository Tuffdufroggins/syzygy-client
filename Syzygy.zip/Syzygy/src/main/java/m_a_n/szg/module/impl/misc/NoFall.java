package m_a_n.szg.module.impl.misc;

import m_a_n.szg.module.Category;
import m_a_n.szg.module.Module;
import net.minecraft.network.play.client.CPacketPlayer;
import org.lwjgl.input.Keyboard;

public class NoFall extends Module {

    public NoFall() {
        super("NoFall", "Removes fall damage", Category.MISC);
        this.setKey(Keyboard.KEY_M);
    }

    public void onEnable() {
    }

    public void onDisable() {
    }

    public void onUpdate() {
        if(mc.player != null) {
            if(mc.player.fallDistance > 2) {
                mc.player.connection.sendPacket(new CPacketPlayer(true));
            }
        }
    }
}
