package m_a_n.szg.ui;

import m_a_n.szg.Client;
import m_a_n.szg.module.Category;
import m_a_n.szg.module.Module;
import m_a_n.szg.util.Tools;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiTextField;
import net.minecraft.client.gui.ScaledResolution;
import org.lwjgl.input.Keyboard;

import java.util.ArrayList;

public class ClickGuiScreen extends GuiScreen {

    public ClickGuiScreen() {
        boostCircles();
    }

    public void initGui() {
        Keyboard.enableRepeatEvents(true);
    }

    public void onGuiClosed() {
        Keyboard.enableRepeatEvents(false);
    }

    public ArrayList<Circle> circles = new ArrayList<Circle>();

    public void drawScreen(int mouseX, int mouseY, float partialTicks) { // Color Scheme: 562dfc be2dfc 2da9fc
        drawGradientRect(0, 0, this.width, this.height, 0x962da9fc, 0x96be2dfc);
        renderCircles();

        for(Category c : Category.values()) {
            int x = (int) c.x;
            int y = (int) c.y;

            if(c.expanded) {
                int count = 0;
                for (Module m : Client.moduleManager.getModulesByCategory(c)) {

                    drawRect(x+1, y+12+count*12+1, x+80+1, y+12+count*12+12+1, 0xAA000000);
                    drawRect(x, y+12+count*12, x+80, y+12+count*12+12, 0xFF4d4c4c);
                    drawString(mc.fontRenderer, m.getName(), x+2, y+12+count*12+2, m.isToggled() ? 0xFF704dff : -1);

                    count++;
                }
            }

            drawRect(x+(c.expanded ? 80 : 1), y+1, x+80+1, y+12+1, 0xAA000000);
            drawRect(x, y, x+80, y+12, 0xFF562dfc);
            drawString(mc.fontRenderer, c.name, x+2, y+2, -1);
        }
    }

    public void mouseClicked(int mouseX, int mouseY, int button) {
        for(Category c : Category.values()) {
            if (Tools.mouseOver(mouseX, mouseY, (int) c.x, (int) c.y, 80, 12)) {
                if(button == 1) {
                    if (Client.moduleManager.getModulesByCategory(c).size() > 0) {
                        c.expanded = !c.expanded;
                    }
                }
                return;
            }
            if(c.expanded) {
                int count = 0;
                for (Module m : Client.moduleManager.getModulesByCategory(c)) {
                    if(button == 0) {
                        if (Tools.mouseOver(mouseX, mouseY, (int) c.x, (int) c.y + 12 + count * 12, 80, 12)) {
                            m.toggle();
                            return;
                        }
                    }
                    count++;
                }
            }
        }

        if(button == 0) {
            if(circles.size() < 150) {
                boostCircles();
            }
        }
    }

    public void mouseReleased(int mouseX, int mouseY, int state) {

    }

    public void mouseClickMove(int mouseX, int mouseY, int clickedMouseButton, long timeSinceLastClick) {

    }

    public void keyTyped(char typedChar, int keyCode) {
        if (keyCode == 1 || keyCode == Client.moduleManager.getModule("ClickGUI").getKey())
        {
            this.mc.displayGuiScreen((GuiScreen)null);

            if (this.mc.currentScreen == null)
            {
                this.mc.setIngameFocus();
            }
        }
    }

    public void renderCircles() {
        ArrayList<Circle> toRemove = new ArrayList<Circle>();
        for(Circle c : circles) {
            c.render();

            ScaledResolution sr = new ScaledResolution(Minecraft.getMinecraft());
            if(c.y > sr.getScaledHeight()+10 || c.x < -10 || c.x > sr.getScaledWidth()+10) {
                toRemove.add(c);
            }
        }

        for(Circle c : toRemove) {
            circles.remove(c);
            if(circles.size() <= 70) {
                circles.add(new Circle(0x962da9fc));
            }
        }
    }

    public void boostCircles() {
        int amount = Tools.randomFrom(40, 60);
        for(int i = 0; i < amount; i++) {
            circles.add(new Circle(0x962da9fc));
        }
    }


}
