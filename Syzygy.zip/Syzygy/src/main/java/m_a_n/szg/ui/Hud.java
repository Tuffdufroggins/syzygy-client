package m_a_n.szg.ui;

import m_a_n.szg.Client;
import m_a_n.szg.module.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

import java.awt.*;
import java.util.Collections;
import java.util.Comparator;

public class Hud extends Gui {

    private Minecraft mc = Minecraft.getMinecraft();

    @SubscribeEvent
    public void renderOverlay(RenderGameOverlayEvent event) {
        Collections.sort(Client.getModules(), new ModuleComparator());
        ScaledResolution sr = new ScaledResolution(mc);
        FontRenderer fr = mc.fontRenderer;

        if(event.getType() == RenderGameOverlayEvent.ElementType.TEXT) {

            GlStateManager.pushMatrix();
            GlStateManager.translate(3, 3, 0);
            GlStateManager.scale(1.5, 1.5, 1);
            GlStateManager.translate(-3, -3, 0);
            fr.drawStringWithShadow(Client.NAME, 3, 3, -1);
            GlStateManager.popMatrix();

            int count = 0;
            for(Module m : Client.getModules()) {
                if(m.isToggled() && m.shownOnHud) {
                    fr.drawStringWithShadow(m.getName(), sr.getScaledWidth()-fr.getStringWidth(m.getName())-3, 3+count*(fr.FONT_HEIGHT+2), getRGB(count* 10L));
                    count++;
                }
            }
        }
    }

    public static class ModuleComparator implements Comparator<Module> {

        @Override
        public int compare(Module o1, Module o2) {
            if(Minecraft.getMinecraft().fontRenderer.getStringWidth(o1.getName()) > Minecraft.getMinecraft().fontRenderer.getStringWidth(o2.getName())) {
                return -1;
            }
            if(Minecraft.getMinecraft().fontRenderer.getStringWidth(o1.getName()) > Minecraft.getMinecraft().fontRenderer.getStringWidth(o2.getName())) {
                return 1;
            }
            return 0;
        }
    }

    public static int getRGB(long delay) {
        int speed = 4;

        float hue = ((System.currentTimeMillis()-delay) % (int)(speed*1000))/(float)(speed*1000);
        return Color.HSBtoRGB(hue, 0.5f, 1f);
    }
}
