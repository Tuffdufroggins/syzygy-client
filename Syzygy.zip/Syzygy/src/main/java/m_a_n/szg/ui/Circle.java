package m_a_n.szg.ui;

import m_a_n.szg.util.RenderUtils;
import m_a_n.szg.util.Tools;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;

import java.util.concurrent.ThreadLocalRandom;

public class Circle {

    public int color;
    public float x;
    public double y;
    public float r;
    public double hSpeed, vSpeed;


    public Circle(int color) {
        this.color = color;

        ScaledResolution sr = new ScaledResolution(Minecraft.getMinecraft());
        this.x = Tools.randomFrom(0, sr.getScaledWidth());
        this.y = ThreadLocalRandom.current().nextDouble(-20, -10);
        this.vSpeed = ThreadLocalRandom.current().nextDouble(0.3, 4);
        this.hSpeed = ThreadLocalRandom.current().nextDouble(-1, 2);
        this.r = (float)ThreadLocalRandom.current().nextDouble(0.5, 4);
    }

    public void render() {
        RenderUtils.drawFilledCircle(x, (float) y, r, color);
        x += hSpeed;
        y += vSpeed;
    }
}
