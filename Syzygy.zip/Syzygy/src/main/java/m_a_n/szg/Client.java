package m_a_n.szg;

import m_a_n.szg.module.Module;
import m_a_n.szg.module.ModuleManager;
import m_a_n.szg.proxy.CommonProxy;
import m_a_n.szg.ui.Hud;
import net.minecraft.block.Block;
import net.minecraft.client.Minecraft;
import net.minecraft.item.Item;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.SidedProxy;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.fml.common.registry.GameRegistry;
import org.lwjgl.input.Keyboard;

import java.util.ArrayList;

@Mod(
        modid = Client.MOD_ID,
        name = Client.NAME,
        version = Client.VERSION,
        acceptedMinecraftVersions = Client.MC_VERSION
)
public class Client {

    public static final String MOD_ID = "szg";
    public static final String NAME = "Syzygy";
    public static final String VERSION = "1.0";
    public static final String MC_VERSION = "1.12.2";
    public static final String CLIENT_PROXY_CLASS = "m_a_n.szg.proxy.ClientProxy";
    public static final String COMMON_PROXY_CLASS = "m_a_n.szg.proxy.CommonProxy";

    public static ModuleManager moduleManager;
    public static Hud hud;

    /**
     * This is the instance of your mod as created by Forge. It will never be null.
     */
    @Mod.Instance(MOD_ID)
    public static Client INSTANCE;

    @SidedProxy(clientSide = CLIENT_PROXY_CLASS, serverSide = COMMON_PROXY_CLASS)
    public static CommonProxy proxy;

    /**
     * This is the first initialization event. Register tile entities here.
     * The registry events below will have fired prior to entry to this method.
     */
    @Mod.EventHandler
    public void preinit(FMLPreInitializationEvent event) {

    }

    /**
     * This is the second initialization event. Register custom recipes
     */
    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        MinecraftForge.EVENT_BUS.register(INSTANCE);
        MinecraftForge.EVENT_BUS.register(new Hud());
        moduleManager = new ModuleManager();
        hud = new Hud();
    }

    /**
     * This is the final initialization event. Register actions from other mods here
     */
    @Mod.EventHandler
    public void postinit(FMLPostInitializationEvent event) {

    }

    @SubscribeEvent
    public void key(InputEvent.KeyInputEvent e) {
        if(Minecraft.getMinecraft().world == null || Minecraft.getMinecraft().player == null)
            return;
        try {
            if(Keyboard.isCreated()) {
                if(Keyboard.getEventKeyState()) {
                    int keyCode = Keyboard.getEventKey();
                    if(keyCode <= 0)
                        return;

                    for(Module m : getModules()) {
                        if(m.getKey() == keyCode) {
                            m.toggle();
                        }
                    }
                }
            }
        } catch (Exception q) {
            q.printStackTrace();
        }
    }

    @SubscribeEvent
    public void tickClient(TickEvent.ClientTickEvent event) {
        for(Module m : getModules()) {
            if(m.isToggled()) {
                m.onUpdate();
            }
        }
    }

    @SubscribeEvent
    public void onWorldRender(RenderWorldLastEvent event) {
        for(Module m : getModules()) {
            if(m.isToggled()) {
                m.onRenderWorld();
            }
        }
    }

    public static ArrayList<Module> getModules() {
        return moduleManager.modules;
    }
}
