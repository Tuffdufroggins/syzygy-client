package m_a_n.szg.util;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderGlobal;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.AxisAlignedBB;
import org.lwjgl.opengl.GL11;

public class RenderUtils {

    public static void drawFilledCircle(float cx, float cy, float r, int c) {
        float currentR = r;
        while(currentR >= 0) {
            drawCircle(cx, cy, currentR, 100, c);
            currentR -= 0.1;
        }
    }

    public static void drawCircle(float cx, float cy, float r, int num_segments, int c) {
        GL11.glPushMatrix();
        cx *= 2.0F;
        cy *= 2.0F;
        float f = (c >> 24 & 0xFF) / 255.0F;
        float f1 = (c >> 16 & 0xFF) / 255.0F;
        float f2 = (c >> 8 & 0xFF) / 255.0F;
        float f3 = (c & 0xFF) / 255.0F;
        float theta = (float) (6.2831852D / num_segments);
        float p = (float) Math.cos(theta);
        float s = (float) Math.sin(theta);
        float x = r *= 2.0F;
        float y = 0.0F;
        enableGL2D();
        GL11.glScalef(0.5F, 0.5F, 0.5F);
        GL11.glColor4f(f1, f2, f3, f);
        GL11.glBegin(2);
        int ii = 0;
        while (ii < num_segments) {
            GL11.glVertex2f(x + cx, y + cy);
            float t = x;
            x = p * x - s * y;
            y = s * t + p * y;
            ii++;
        }
        GL11.glEnd();
        GL11.glScalef(2.0F, 2.0F, 2.0F);
        disableGL2D();
        GlStateManager.color(1, 1, 1, 1);
        GL11.glPopMatrix();
    }

    public static void enableGL2D() {
        GL11.glDisable(2929);
        GL11.glEnable(3042);
        GL11.glDisable(3553);
        GL11.glBlendFunc(770, 771);
        GL11.glDepthMask(true);
        GL11.glEnable(2848);
        GL11.glHint(3154, 4354);
        GL11.glHint(3155, 4354);
    }

    public static void disableGL2D() {
        GL11.glEnable(3553);
        GL11.glDisable(3042);
        GL11.glEnable(2929);
        GL11.glDisable(2848);
        GL11.glHint(3154, 4352);
        GL11.glHint(3155, 4352);
    }

    public static void renderFilledBB(Entity entity, double red, double green, double blue, double opacity) {
        GL11.glBlendFunc(770, 771);
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glLineWidth(3.0F); //2.0f
        GL11.glDisable(GL11.GL_TEXTURE_2D);
        GL11.glDisable(GL11.GL_DEPTH_TEST);
        GL11.glDepthMask(false);

        GL11.glColor4d(red, green, blue, opacity);

        Minecraft.getMinecraft().getRenderManager();
        RenderGlobal.renderFilledBox(new AxisAlignedBB(
                entity.getEntityBoundingBox().minX-0.05-entity.posX+(entity.posX-Minecraft.getMinecraft().getRenderManager().viewerPosX),
                entity.getEntityBoundingBox().minY-0.05-entity.posY+(entity.posY-Minecraft.getMinecraft().getRenderManager().viewerPosY),
                entity.getEntityBoundingBox().minZ-0.05-entity.posZ+(entity.posZ-Minecraft.getMinecraft().getRenderManager().viewerPosZ),

                entity.getEntityBoundingBox().maxX+0.05-entity.posX+(entity.posX-Minecraft.getMinecraft().getRenderManager().viewerPosX),
                entity.getEntityBoundingBox().maxY+0.1-entity.posY+(entity.posY-Minecraft.getMinecraft().getRenderManager().viewerPosY),
                entity.getEntityBoundingBox().maxZ+0.05-entity.posZ+(entity.posZ-Minecraft.getMinecraft().getRenderManager().viewerPosZ)),
                (float)red, (float)green, (float)blue, (float)opacity);
        GL11.glColor4d(1, 1, 1, 1);
        GL11.glEnable(GL11.GL_TEXTURE_2D);
        GL11.glEnable(GL11.GL_DEPTH_TEST);
        GL11.glDepthMask(true);
        GL11.glDisable(GL11.GL_BLEND);
    }

    public static void renderOutlineBB(Entity entity, double red, double green, double blue, double opacity) {
        GL11.glBlendFunc(770, 771);
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glLineWidth(3.0F); //2.0f
        GL11.glDisable(GL11.GL_TEXTURE_2D);
        GL11.glDisable(GL11.GL_DEPTH_TEST);
        GL11.glDepthMask(false);

        GL11.glColor4d(red, green, blue, opacity);

        Minecraft.getMinecraft().getRenderManager();
        RenderGlobal.drawSelectionBoundingBox(new AxisAlignedBB(
                        entity.getEntityBoundingBox().minX-0.05-entity.posX+(entity.posX-Minecraft.getMinecraft().getRenderManager().viewerPosX),
                        entity.getEntityBoundingBox().minY-0.05-entity.posY+(entity.posY-Minecraft.getMinecraft().getRenderManager().viewerPosY),
                        entity.getEntityBoundingBox().minZ-0.05-entity.posZ+(entity.posZ-Minecraft.getMinecraft().getRenderManager().viewerPosZ),

                        entity.getEntityBoundingBox().maxX+0.05-entity.posX+(entity.posX-Minecraft.getMinecraft().getRenderManager().viewerPosX),
                        entity.getEntityBoundingBox().maxY+0.1-entity.posY+(entity.posY-Minecraft.getMinecraft().getRenderManager().viewerPosY),
                        entity.getEntityBoundingBox().maxZ+0.05-entity.posZ+(entity.posZ-Minecraft.getMinecraft().getRenderManager().viewerPosZ)),
                (float)red, (float)green, (float)blue, (float)opacity);
        GL11.glColor4d(1, 1, 1, 1);
        GL11.glEnable(GL11.GL_TEXTURE_2D);
        GL11.glEnable(GL11.GL_DEPTH_TEST);
        GL11.glDepthMask(true);
        GL11.glDisable(GL11.GL_BLEND);
    }

}
