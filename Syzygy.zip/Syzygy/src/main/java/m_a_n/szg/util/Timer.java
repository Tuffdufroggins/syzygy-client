package m_a_n.szg.util;

public class Timer {

    public long lastMS = System.currentTimeMillis();

    public long lastNano = System.nanoTime();

    public void reset() {
        lastMS = System.currentTimeMillis();
        lastNano = System.nanoTime();
    }

    public void reset(double offset) {
        lastMS = System.currentTimeMillis()+(long)offset;
        lastNano = System.nanoTime()+(long)(offset*1000000);
    }

    public boolean hasTimeElapsed(long time) {
        if(System.currentTimeMillis()-lastMS >= time) {
            return true;
        }
        return false;
    }

    public boolean hasTimeElapsed(long time, boolean reset) {
        if(System.currentTimeMillis()-lastMS >= time) {
            if(reset)
                reset();
            return true;
        }
        return false;
    }

    public boolean hasTimeElapsedNano(long time) {
        if(System.nanoTime()-lastNano >= time) {
            return true;
        }
        return false;
    }

    public boolean hasTimeElapsedNano(long time, boolean reset) {
        if(System.nanoTime()-lastNano >= time) {
            if(reset)
                reset();
            return true;
        }
        return false;
    }

    public long timeElapsed() {
        return System.currentTimeMillis()-lastMS;
    }

    public long timeElapsedNano() {
        return System.nanoTime()-lastNano;
    }
}
