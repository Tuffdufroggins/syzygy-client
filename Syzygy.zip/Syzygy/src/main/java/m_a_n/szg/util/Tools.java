package m_a_n.szg.util;

public class Tools {
    // Random Numbers
    public static int randomFrom(int min, int max){
        return((int)(Math.random() * (max+1-min) + min));
    }
    public static double randomFrom(double min, double max){
        return((Math.random() * (max+1-min) + min));
    }
    public static float randomFrom(float min, float max){
        return (float) (Math.random() * (max+1-min) + min);
    }
    public static double randomFrom(double min, double max, float decimal){
        return(Math.round((Math.random() * (max+1-min) + min)/decimal)*decimal);
    }
    public static float randomFrom(float min, float max, float decimal){
        return((float)(Math.round((Math.random() * (max+1-min) + min)/decimal)*decimal));
    }
    public static short randomFrom(short min, short max){
        return((short)(Math.random() * (max+1-min) + min));
    }
    public static boolean randomBool(){
        return (int) (Math.random() * 2) == 0;
    }

    public static boolean percentChance(int percent) {
        return Math.random()*100 < percent;
    }

    // Clamp
    public static int clamp(int var, int min, int max) {
        if (var >= min && var <= max) {
            return var;
        } else if (var < min) {
            return min;
        } else {
            return max;
        }
    }

    public static float clamp(float var, float min, float max) {
        if (var >= min && var <= max) {
            return var;
        } else if (var < min) {
            return min;
        } else {
            return max;
        }
    }

    // Sign
    public static int sign(double var) {
        int sign = 0;
        if(var < 0) {
            sign = -1;
        } else if (var > 0) {
            sign = 1;
        }
        return sign;
    }

    // Mouse Over
    public static boolean mouseOver(int mx, int my, int x, int y, int width, int height) {
        if(mx > x && mx < x + width) {
            if (my > y && my < y + height) {
                return true;
            }
        }
        return false;
    }
}
