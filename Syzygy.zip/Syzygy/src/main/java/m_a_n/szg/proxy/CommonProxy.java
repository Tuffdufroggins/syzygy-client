package m_a_n.szg.proxy;

public class CommonProxy {
}
