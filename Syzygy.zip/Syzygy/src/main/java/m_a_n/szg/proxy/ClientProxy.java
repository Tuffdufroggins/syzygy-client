package m_a_n.szg.proxy;

public class ClientProxy extends CommonProxy {
}
